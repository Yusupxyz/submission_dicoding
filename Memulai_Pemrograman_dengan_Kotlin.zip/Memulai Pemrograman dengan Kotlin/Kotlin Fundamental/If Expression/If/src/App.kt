// main function
fun main() {
    val officeOpen = 7
    val now = 20
    if (now > officeOpen) {
        println("office already open")
    }
}