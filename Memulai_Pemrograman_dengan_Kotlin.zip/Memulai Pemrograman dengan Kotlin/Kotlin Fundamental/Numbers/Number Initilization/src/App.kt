
/* Int (32 Bit) */
val intNumbers = 100

/* Long (64 Bit) */
val longNumber: Long = 100
val longNumbers = 100L

/* Short (16 Bit) */
val shortNumber: Short = 10

/* Byte (8 Bit) */
val byteNumber = 0b11010010

/* Double (64 Bit) */
val doubleNumbers = 1.3

fun main() {
    println("Numbers")
}