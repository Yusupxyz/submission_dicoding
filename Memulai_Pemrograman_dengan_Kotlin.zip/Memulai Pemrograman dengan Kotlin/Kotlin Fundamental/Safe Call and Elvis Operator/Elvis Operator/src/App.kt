fun main() {
    val text: String? = "1"
    val textLength = text?.length ?: 7
    print(textLength)
}