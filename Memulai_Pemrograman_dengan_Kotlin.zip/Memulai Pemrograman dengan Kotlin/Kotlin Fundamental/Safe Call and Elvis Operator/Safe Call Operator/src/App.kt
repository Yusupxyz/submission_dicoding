fun main() {
    val text: String? = null
    print(text?.length)

}