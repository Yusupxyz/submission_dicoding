package com.dicoding.oop

import com.dicoding.oop.utils.*

fun main() {
    sayHello()
    println(factorial(4.0))
    println(pow(3.0, 2.0))
    println(PI)
    println(areaOfCircle(13.0))
}