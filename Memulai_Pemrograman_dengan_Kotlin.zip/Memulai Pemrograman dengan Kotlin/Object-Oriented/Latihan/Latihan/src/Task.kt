// TODO 1
class Cat(private val name: String) {
    var sleep: Boolean = false
        get() = field
        set(value) {field=value}

    fun toSleep() {
        if (!sleep){
            println("Fungsi getter dipanggil")
            println("$name, let's play!")
        }else{
            println("Fungsi setter dipanggil")
            println("Fungsi getter dipanggil")
            println("$name, sleep!")
        }

    }
}

fun main() {

    // TODO 2
    val gippy = Cat("Gippy")

    gippy.toSleep()
    gippy.sleep = true
    gippy.toSleep()
}